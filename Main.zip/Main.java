//The input to your solution will be passed in as String[] args
import java.util.Random;
import java.util.Scanner;

public class Main {
	private static final String LENGABURU = "Lengaburu";
	private static final String ENCHAI = "Enchai";
	private static final String CLEAR = "Clear";
	private static final String CLOUDY = "Cloudy";
	private static final String DAY = "Day";
	private static final String NIGHT = "Night";

	public static void main(String[] args) {
	    Scanner in = new Scanner(System.in);
	    System.out.println("Enter Weather: " );
	    String weather = in.nextLine();
	    System.out.println("Enter Day / Night: " );
	    String dayOrNight = in.nextLine();
		boolean probability = new Random().nextInt(2) == 0;
		if (probability) {
			if (CLOUDY.equals(weather) && DAY.equals(dayOrNight) ||
					CLEAR.equals(weather) && NIGHT.equals(dayOrNight)) {
				System.out.println(LENGABURU + " Wins toss and bats");
				return;
			}
			display(LENGABURU, weather, dayOrNight);
		} else {
			if (CLOUDY.equals(weather) && DAY.equals(dayOrNight) || 
					CLEAR.equals(weather) && NIGHT.equals(dayOrNight)) {
				System.out.println(ENCHAI + " Wins toss and bats");
				return;
			}
			display(ENCHAI, weather, dayOrNight);
		}
	}

	private static void display(String winner, String weather, String dayOrNight) {
		switch (winner) {
		case LENGABURU:
			if (CLEAR.equals(weather) && DAY.equals(dayOrNight))
				System.out.println(LENGABURU + " Wins toss and bats");
			else
				System.out.println(LENGABURU + " Wins toss and bowls");
			break;

		case ENCHAI:
			if (CLOUDY.equals(weather) && NIGHT.equals(dayOrNight))
				System.out.println(ENCHAI + " Wins toss and bats");
			else
				System.out.println(ENCHAI + " Wins toss and bowls");
			break;

		default:
			System.out.println(winner + " Wins toss and bats");

		}
	}
}